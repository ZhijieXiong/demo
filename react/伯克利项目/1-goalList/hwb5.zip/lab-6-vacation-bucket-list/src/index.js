import React from "react";
import ReactDOM from "react-dom";
import Item from "./Item";

import "./styles.css";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.placeholderList = ["Item placeholder 1", "Item placeholder 2"];
  }

  handleInputChange(event) {}

  addItem() {}

  render() {
    return (
      <div className="list-container">
        <div className="input-container">
          <input
            className="list-input"
            placeholder="New Item"
            value="CHANGE ME!"
            onChange={e => this.handleInputChange(e)}
          />
          <button className="list-submit" onClick={() => this.addItem()}>
            Submit
          </button>
        </div>
        <ul className="item-list">
          {this.placeholderList.map((item, index) => (
            <Item key={index} text={item} />
          ))}
        </ul>
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
