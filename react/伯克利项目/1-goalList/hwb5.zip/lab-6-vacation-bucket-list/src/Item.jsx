import React from "react";

class Item extends React.Component {
  constructor(props) {
    super(props);
  }

  toggleDone() {}

  render() {
    let className = "";
    return (
      <div>
        <li className={className} onClick={() => this.toggleDone()}>
          {"Replace me!"}
        </li>
      </div>
    );
  }
}

export default Item;
