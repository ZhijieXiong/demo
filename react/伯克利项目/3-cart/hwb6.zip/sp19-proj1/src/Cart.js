import React from "react";
import "./styles/cart.css";

class Cart extends React.Component {

  render() {
    return (
        <div className="page-content">
            <h2>Add your products here!</h2>
        </div>
    );
  }

}

export default Cart;
