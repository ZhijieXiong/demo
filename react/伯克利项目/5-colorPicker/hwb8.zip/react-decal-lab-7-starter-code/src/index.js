import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";

function ColorInput({ color, onChange }) {
  return (
    <div
      className="ui text container field labeled input"
      style={{ marginBottom: "10px" }}
    >
      <label className="ui label">{color}</label>
      <input
        type="text"
        placeholder="(0-255)"
        onChange={e => onChange(e.target.value)}
      />
    </div>
  );
}

class App extends React.Component {
  constructor(props) {
    super(props);
    // YOUR CODE HERE: Initialize your state!
  }

  render() {
    return (
      <div className="App">
        <h1>Color Picker</h1>
        {/* YOUR CODE HERE: Part 1 */}
        {/*
            An example input is below.
            Don't forget to add an onChange event handler!.
          */}
        <div className="ui labeled input">
          <div className="ui label">Red</div>
          <input type="text" placeholder="(0-255)" />
        </div>
        <div
          className="preview"
          style={{
            width: "100px",
            height: "100px",
            backgroundColor: "YOUR CODE HERE: Part 2"
          }}
        />
        {/* YOUR CODE HERE: Part 3 */}
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
