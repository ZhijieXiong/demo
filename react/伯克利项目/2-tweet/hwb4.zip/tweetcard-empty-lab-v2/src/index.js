// ----- DON'T MODIFY BELOW -----
import React from "react";
import ReactDOM from "react-dom";
import TweetCard from "./TweetCard.jsx";
import "./styles.css";

const tweet = {
  name: "Ken Chen",
  username: "@kennethyChennethy",
  imageURL:
    "https://raw.githubusercontent.com/Ashwinvalento/cartoon-avatar/master/lib/images/male/45.png",
  tweet:
    "For 2019, I hope that I can finally build the perfect sandwich. #HappyNewYear #2019",
  timestamp: "12:01 AM - 1 Jan 2019",
  retweets: 5429,
  likes: 1872,
  verified: true
};

const rootElement = document.getElementById("root");
ReactDOM.render(<TweetCard tweet={tweet} />, rootElement);
// ----- DON'T MODIFY ABOVE -----
